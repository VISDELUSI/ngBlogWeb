'use strict';

angular.module('myApp.view1', ['ngRoute'])

  .config(['$routeProvider', function ($routeProvider) {
    $routeProvider.when('/view1', {
      templateUrl: 'view1/view1.html',
      controller: 'View1Ctrl'
    });
  }])

  .controller('View1Ctrl', ['$http', '$scope', function View1Ctrl($http, $scope){
      
      $http.get('https://jsonplaceholder.typicode.com/posts')
      .then((response) => {
        console.log(response.data.length);
      $scope.posts = response.data;

      })
      .catch(err => console.log(err));

    }]);

// angular.module('myApp.view1',['ngRoute'])
//   .component('view1',{
//     templateUrl:'view1/view1.html',
//     controller:['$http', function View1Ctrl($http){

//       $http.get('https://jsonplaceholder.typicode.com/posts')
//       .then((response) => {
//         self.posts = response.data;
//       })
//       .catch(err => console.log(err));


//     } 
  
//   ]
//   });