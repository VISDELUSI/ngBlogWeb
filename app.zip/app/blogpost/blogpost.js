
angular.module('myApp.blogpost', ['ngRoute'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/blogpost/:id', {
            templateUrl: 'blogpost/showblog.html',
            controller: 'BlogCtrl'
        });
    }])

    .controller('BlogCtrl', ['$http', '$scope', '$routeParams', function BlogCtrl($http, $scope, $routeParams) {

        $scope.posts;
        let bid = $routeParams.id;

        $http.get(`https://jsonplaceholder.typicode.com/posts/${$routeParams.id}`)
            .then((response) => {
                $scope.blogs = response.data;


                //   $http.get('https://jsonplaceholder.typicode.com/posts')
                //   .then((response) => {
                //     console.log(response.data.length);
                //     $scope.posts = response.data;

                //     for (pos in $scope.posts){
                //         console.log(pos.id);
                //         if (pos.id == bid){
                //           console.log(pos.id);
                //             $scope.blog = {
                //                 id : pos.id,
                //                 title : pos.title,
                //                 content : pos.body
                //             }
                //         }
                //     }



            })
            .catch(err => console.log(err));








    }]);